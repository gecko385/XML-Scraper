#!/usr/bin/perl
#-----------------------------------------------------------------------
# test program for XML::Scraper
#-----------------------------------------------------------------------

use XML::LibXML qw(:libxml);
use XML::Scraper;

use Data::Dumper::Concise;
use File::Slurp;
use JSON;
use YAML;

my $json = JSON->new->pretty(1);

#-----------------------------------------------------------------------
# command line
#-----------------------------------------------------------------------

my $config_file = shift or die "need config file";
my $xml_file    = shift or die "need XML ";
my $output_file = shift or die "Need outout file";

#-----------------------------------------------------------------------
# get the config
#-----------------------------------------------------------------------

my $config = YAML::LoadFile $config_file;

#-----------------------------------------------------------------------
# load the XML
#-----------------------------------------------------------------------

my $dom = XML::LibXML->load_xml(location => $xml_file );

#-----------------------------------------------------------------------
# create a new scraper
#-----------------------------------------------------------------------

my $scraper = XML::Scraper->new;

#-----------------------------------------------------------------------
# do the parse for
#-----------------------------------------------------------------------
my %results;

$results{playlistarray} = $scraper->parseDOM($dom,$config->{playlistarray});
$results{playlisthash}  = $scraper->parseDOM($dom,$config->{playlisthash});

#-----------------------------------------------------------------------
# output the data
#-----------------------------------------------------------------------

write_file($output_file, Data::Dumper::Concise::Dumper(\%results));

#-----------------------------------------------------------------------
# print the generated code - should see two subs
#-----------------------------------------------------------------------

print Data::Dumper::Concise::Dumper($scraper->getCode());


