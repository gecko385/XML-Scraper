{
  playlistarray => {
    movie => [
      {
        cast => [
          {
            name => "Tom Hanks",
            role => "Jim Lovell",
          },
          {
            name => "Bill Paxton",
            role => "Fred Haise",
          },
          {
            name => "Kevin Bacon",
            role => "Jack Swigert",
          },
          {
            name => "Gary Sinise",
            role => "Ken Mattingly",
          },
          {
            name => "Ed Harris",
            role => "Gene Kranz",
          },
        ],
        director => "Ron Howard",
        genre => [
          "adventure",
          "drama",
        ],
        id => "tt0112384",
        "imdb-info" => [
          {
            score => "7.6",
            synopsis => "\n        NASA must devise a strategy to return Apollo 13 to Earth safely\n        after the spacecraft undergoes massive internal damage putting\n        the lives of the three astronauts on board in jeopardy.\n      ",
            url => "http://www.imdb.com/title/tt0112384/",
          },
        ],
        "mpaa-rating" => "PG",
        "release-date" => "1995-06-30",
        "running-time" => 140,
        title => "Apollo 13",
      },
      {
        cast => [
          {
            name => "George Clooney",
            role => "Chris Kelvin",
          },
          {
            name => "Natascha McElhone",
            role => "Rheya",
          },
          {
            name => "Ulrich Tukur",
            role => "Gibarian",
          },
        ],
        director => "Steven Soderbergh",
        genre => [
          "drama",
          "mystery",
          "romance",
        ],
        id => "tt0307479",
        "imdb-info" => [
          {
            score => "6.2",
            synopsis => "\n        A troubled psychologist is sent to investigate the crew of an\n        isolated research station orbiting a bizarre planet.\n      ",
            url => "http://www.imdb.com/title/tt0307479/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2002-11-27",
        "running-time" => 99,
        title => "Solaris",
      },
      {
        cast => [
          {
            name => "Asa Butterfield",
            role => "Ender Wiggin",
          },
          {
            name => "Harrison Ford",
            role => "Colonel Graff",
          },
          {
            name => "Hailee Steinfeld",
            role => "Petra Arkanian",
          },
        ],
        director => "Gavin Hood",
        genre => [
          "action",
          "scifi",
        ],
        id => "tt1731141",
        "imdb-info" => [
          {
            score => "6.7",
            synopsis => "\n        Young Ender Wiggin is recruited by the International Military\n        to lead the fight against the Formics, a genocidal alien race\n        which nearly annihilated the human race in a previous invasion.\n      ",
            url => "http://www.imdb.com/title/tt1731141/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2013-11-01",
        "running-time" => 114,
        title => "Ender's Game",
      },
      {
        cast => [
          {
            name => "Matthew McConaughey",
            role => "Cooper",
          },
          {
            name => "Anne Hathaway",
            role => "Brand",
          },
          {
            name => "Jessica Chastain",
            role => "Murph",
          },
          {
            name => "Michael Caine",
            role => "Professor Brand",
          },
        ],
        director => "Christopher Nolan",
        genre => [
          "adventure",
          "drama",
          "scifi",
        ],
        id => "tt0816692",
        "imdb-info" => [
          {
            score => "8.6",
            synopsis => "\n        A team of explorers travel through a wormhole in space in an\n        attempt to ensure humanity's survival.\n      ",
            url => "http://www.imdb.com/title/tt0816692/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2014-11-07",
        "running-time" => 169,
        title => "Interstellar",
      },
      {
        cast => [
          {
            name => "Matt Damon",
            role => "Mark Watney",
          },
          {
            name => "Jessica Chastain",
            role => "Melissa Lewis",
          },
          {
            name => "Kristen Wiig",
            role => "Annie Montrose",
          },
        ],
        director => "Ridley Scott",
        genre => [
          "adventure",
          "drama",
          "scifi",
        ],
        id => "tt3659388",
        "imdb-info" => [
          {
            score => "8.1",
            synopsis => "\n        During a manned mission to Mars, Astronaut Mark Watney is\n        presumed dead after a fierce storm and left behind by his crew.\n        But Watney has survived and finds himself stranded and alone on\n        the hostile planet. With only meager supplies, he must draw upon\n        his ingenuity, wit and spirit to subsist and find a way to\n        signal to Earth that he is alive.\n      ",
            url => "http://www.imdb.com/title/tt3659388/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2015-10-02",
        "running-time" => 144,
        title => "The Martian",
      },
    ],
  },
  playlisthash => {
    movie => {
      tt0112384 => {
        cast => [
          {
            name => "Tom Hanks",
            role => "Jim Lovell",
          },
          {
            name => "Bill Paxton",
            role => "Fred Haise",
          },
          {
            name => "Kevin Bacon",
            role => "Jack Swigert",
          },
          {
            name => "Gary Sinise",
            role => "Ken Mattingly",
          },
          {
            name => "Ed Harris",
            role => "Gene Kranz",
          },
        ],
        director => "Ron Howard",
        genre => [
          "adventure",
          "drama",
        ],
        id => "tt0112384",
        "imdb-info" => [
          {
            score => "7.6",
            synopsis => "\n        NASA must devise a strategy to return Apollo 13 to Earth safely\n        after the spacecraft undergoes massive internal damage putting\n        the lives of the three astronauts on board in jeopardy.\n      ",
            url => "http://www.imdb.com/title/tt0112384/",
          },
        ],
        "mpaa-rating" => "PG",
        "release-date" => "1995-06-30",
        "running-time" => 140,
        title => "Apollo 13",
      },
      tt0307479 => {
        cast => [
          {
            name => "George Clooney",
            role => "Chris Kelvin",
          },
          {
            name => "Natascha McElhone",
            role => "Rheya",
          },
          {
            name => "Ulrich Tukur",
            role => "Gibarian",
          },
        ],
        director => "Steven Soderbergh",
        genre => [
          "drama",
          "mystery",
          "romance",
        ],
        id => "tt0307479",
        "imdb-info" => [
          {
            score => "6.2",
            synopsis => "\n        A troubled psychologist is sent to investigate the crew of an\n        isolated research station orbiting a bizarre planet.\n      ",
            url => "http://www.imdb.com/title/tt0307479/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2002-11-27",
        "running-time" => 99,
        title => "Solaris",
      },
      tt0816692 => {
        cast => [
          {
            name => "Matthew McConaughey",
            role => "Cooper",
          },
          {
            name => "Anne Hathaway",
            role => "Brand",
          },
          {
            name => "Jessica Chastain",
            role => "Murph",
          },
          {
            name => "Michael Caine",
            role => "Professor Brand",
          },
        ],
        director => "Christopher Nolan",
        genre => [
          "adventure",
          "drama",
          "scifi",
        ],
        id => "tt0816692",
        "imdb-info" => [
          {
            score => "8.6",
            synopsis => "\n        A team of explorers travel through a wormhole in space in an\n        attempt to ensure humanity's survival.\n      ",
            url => "http://www.imdb.com/title/tt0816692/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2014-11-07",
        "running-time" => 169,
        title => "Interstellar",
      },
      tt1731141 => {
        cast => [
          {
            name => "Asa Butterfield",
            role => "Ender Wiggin",
          },
          {
            name => "Harrison Ford",
            role => "Colonel Graff",
          },
          {
            name => "Hailee Steinfeld",
            role => "Petra Arkanian",
          },
        ],
        director => "Gavin Hood",
        genre => [
          "action",
          "scifi",
        ],
        id => "tt1731141",
        "imdb-info" => [
          {
            score => "6.7",
            synopsis => "\n        Young Ender Wiggin is recruited by the International Military\n        to lead the fight against the Formics, a genocidal alien race\n        which nearly annihilated the human race in a previous invasion.\n      ",
            url => "http://www.imdb.com/title/tt1731141/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2013-11-01",
        "running-time" => 114,
        title => "Ender's Game",
      },
      tt3659388 => {
        cast => [
          {
            name => "Matt Damon",
            role => "Mark Watney",
          },
          {
            name => "Jessica Chastain",
            role => "Melissa Lewis",
          },
          {
            name => "Kristen Wiig",
            role => "Annie Montrose",
          },
        ],
        director => "Ridley Scott",
        genre => [
          "adventure",
          "drama",
          "scifi",
        ],
        id => "tt3659388",
        "imdb-info" => [
          {
            score => "8.1",
            synopsis => "\n        During a manned mission to Mars, Astronaut Mark Watney is\n        presumed dead after a fierce storm and left behind by his crew.\n        But Watney has survived and finds himself stranded and alone on\n        the hostile planet. With only meager supplies, he must draw upon\n        his ingenuity, wit and spirit to subsist and find a way to\n        signal to Earth that he is alive.\n      ",
            url => "http://www.imdb.com/title/tt3659388/",
          },
        ],
        "mpaa-rating" => "PG-13",
        "release-date" => "2015-10-02",
        "running-time" => 144,
        title => "The Martian",
      },
    },
  },
}
